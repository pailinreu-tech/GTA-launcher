package com.gta.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private LinearLayout root;
    private int page = 0;
    private boolean showTips = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radiusDp * getResources().getDisplayMetrics().density);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(12, 8, 12, 8);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setBackground(rounded(Color.rgb(174, 24, 24), 14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, 10, 0, 10);
        b.setLayoutParams(p);
        return b;
    }

    private void setupRoot() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(24, 30, 24, 24);
        root.setBackgroundColor(Color.rgb(10, 10, 10));
        setContentView(root);
    }

    private void addSpacer() {
        View v = new View(this);
        root.addView(v, new LinearLayout.LayoutParams(1, 12));
    }

    private void showHome() {
        page = 0;
        setupRoot();

        TextView logo = text("GTA", 42, Color.WHITE, true);
        logo.setBackground(rounded(Color.rgb(174, 24, 24), 18));
        LinearLayout.LayoutParams logoP = new LinearLayout.LayoutParams(220, 100);
        logoP.setMargins(0, 16, 0, 12);
        root.addView(logo, logoP);

        root.addView(text("LAUNCHER", 20, Color.LTGRAY, true));
        root.addView(text("MINECRAFT EDITION", 13, Color.rgb(190, 190, 190), false));
        addSpacer();

        Button play = button("▶  PLAY MINECRAFT");
        play.setOnClickListener(v -> launchMinecraft());
        root.addView(play);

        Button settings = button("⚙  Settings");
        settings.setBackground(rounded(Color.rgb(45, 45, 45), 14));
        settings.setOnClickListener(v -> showSettings());
        root.addView(settings);

        TextView note = text("This app opens Minecraft if it is installed.", 12,
                Color.GRAY, false);
        root.addView(note);
        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, 0, 1));
        root.addView(text("GTA Launcher • v1.0", 12, Color.DKGRAY, false));
    }

    private void launchMinecraft() {
        Intent intent = getPackageManager().getLaunchIntentForPackage("com.mojang.minecraftpe");
        if (intent != null) {
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                Toast.makeText(this, "Could not open Minecraft.", Toast.LENGTH_LONG).show();
            }
        } else {
            new AlertDialog.Builder(this)
                .setTitle("Minecraft not found")
                .setMessage("Install the official Minecraft app first, then try again.")
                .setPositiveButton("OK", null)
                .show();
        }
    }

    private void showSettings() {
        page = 1;
        setupRoot();
        root.addView(text("SETTINGS", 28, Color.WHITE, true));
        addSpacer();

        TextView status = text("Launcher version: 1.0", 16, Color.LTGRAY, false);
        root.addView(status);
        TextView tip = text("Launch target: Minecraft for Android", 14, Color.GRAY, false);
        root.addView(tip);

        Button tips = button("Show launch tips: " + (showTips ? "ON" : "OFF"));
        tips.setBackground(rounded(Color.rgb(45, 45, 45), 14));
        tips.setOnClickListener(v -> {
            showTips = !showTips;
            tips.setText("Show launch tips: " + (showTips ? "ON" : "OFF"));
            Toast.makeText(this, showTips ? "Tips enabled" : "Tips disabled",
                    Toast.LENGTH_SHORT).show();
        });
        root.addView(tips);

        if (showTips) {
            root.addView(text("Make sure Minecraft is installed and updated.", 13,
                    Color.LTGRAY, false));
        }

        View gap = new View(this);
        root.addView(gap, new LinearLayout.LayoutParams(1, 0, 1));
        Button back = button("← Back");
        back.setBackground(rounded(Color.rgb(45, 45, 45), 14));
        back.setOnClickListener(v -> showHome());
        root.addView(back);
    }

    @Override
    public void onBackPressed() {
        if (page == 1) showHome();
        else super.onBackPressed();
    }
}
